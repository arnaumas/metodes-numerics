float mitja_fl(float*, int n);
float var2_fl(float*, float, int n);
float var1_fl(float*, int n);

double mitja_do(double*, int n);
double var2_do(double*, double, int n);
double var1_do(double*, int n);
